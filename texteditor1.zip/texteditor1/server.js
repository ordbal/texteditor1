const express = require("express");
const fs = require("fs");
const path = require("path");
const bodyParser = require("body-parser");

const app = express();
const PORT = 3000;

// Middleware a JSON adatok kezelésére
app.use(bodyParser.json());

// Statikus fájlok kiszolgálása a 'public' mappából
app.use(express.static(path.join(__dirname, "public")));

// /read végpont - fájl olvasása és visszaküldése
app.get("/read", (req, res) => {
  fs.readFile("szoveg.txt", "utf8", (err, data) => {
    if (err) {
      return res.status(500).json({ message: "Error reading file" });
    }
    res.json({ content: data });
  });
});

// /save végpont - fájl mentése a szerkesztett szöveggel
app.post("/save", (req, res) => {
  const newText = req.body.content;
  fs.writeFile("szoveg.txt", newText, "utf8", (err) => {
    if (err) {
      return res.status(500).json({ message: "Error writing file" });
    }
    res.json({ message: "File saved successfully" });
  });
});

// Szerver futtatása
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
