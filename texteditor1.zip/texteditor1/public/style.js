
    document.addEventListener('DOMContentLoaded', function() {
        // A szöveg betöltése a /read végpontról
        fetch('/read')
            .then(response => response.json())
            .then(data => {
                document.getElementById('textContent').value = data.content;
            })
            .catch(error => console.error('Error:', error));

        // A mentés gomb működése
        document.getElementById('saveBtn').addEventListener('click', function() {
            const content = document.getElementById('textContent').value;

            fetch('/save', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ content })
            })
            .then(response => response.json())
            .then(data => {
                const statusElement = document.getElementById('status');
                statusElement.textContent = 'Sikeresen elmentve!';
                statusElement.classList.add('show');
                
                // Az üzenet eltüntetése 3 másodperc után
                setTimeout(() => {
                    statusElement.classList.remove('show');
                }, 3000);
            })
            .catch(error => console.error('Error:', error));
        });
    });

